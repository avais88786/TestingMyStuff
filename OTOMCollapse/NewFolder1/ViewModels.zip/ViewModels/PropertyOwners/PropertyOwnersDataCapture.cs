﻿using Foolproof;
using OpenGI.MVC.Attributes;
using OpenGI.Resources.iMarket;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OpenGI.MVC.ViewModels.PropertyOwners
{
    ////public class AddressLookup
    ////{
    ////    [Required]
    ////    public string AddressLineOne { get; set; }

    ////    public string AddressLineTwo { get; set; }

    ////    public string AddressLineThree { get; set; }

    ////    [Required]
    ////    public string Postcode { get; set; }
    ////}

    ////public class SomethingNew
    ////{
    ////    public string WhatIsIt { get; set; }
    ////}

    public class PersonalInformation
    {
        [Display(Name = "Title")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "PersonalInformationTitleRequired")]
        public int Title { get; set; }

        [Display(Name = "First name")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "PersonalInformationFirstNameRequired")]
        [MaxLength(40)]
        public string FirstName { get; set; }

        [Display(Name = "Last name")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "PersonalInformationLastNameRequired")]
        [MaxLength(40)]
        public string LastName { get; set; }
    }

    public class AddressInformation
    {
        [Display(Name = "Address line 1")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "AddressInformationAddressLineOneRequired")]
        [MaxLength(40)]
        public string AddressLineOne { get; set; }

        [Display(Name = "Address line 2")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "AddressInformationAddressLineTwoRequired")]
        [MaxLength(40)]
        public string AddressLineTwo { get; set; }

        [Display(Name = "Postcode")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "AddressInformationPostcodeRequired")]
        [MaxLength(10)]
        [UIHint("Postcode")]
        [RegularExpression("^([A-PR-UWYZ](([0-9](([0-9]|[A-HJKSTUW])?)?)|([A-HK-Y][0-9]([0-9]|[ABEHMNPRVWXY])?)) [0-9][ABD-HJLNP-UW-Z]{2})|GIR 0AA$",
                            ErrorMessage = "Please enter a valid UK postcode.")]
        public string Postcode { get; set; }
    }

    public class SubsidiaryCompany : RepeatGroupBase
    {
        [Display(Name = "Cover under policy")]
        //[RequiredIf("SubsidiaryCompaniesExist", true)]
        public bool CoveredUnderPolicy { get; set; }

        [Display(Name = "Company name")]
        //[RequiredIf("SubsidiaryCompaniesExist", true, ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "SubsidiaryCompanyCompanyNameRequired")]
        [MaxLength(630)]
        public string CompanyName { get; set; }

        [Display(Name = "Address information")]
        public AddressInformation AddressInformation { get; set; }

        [Display(Name = "Exempt from HMRC employers reference number")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "ExemptFromHMCEERNRequired")]
        public bool ExemptFromHMCEEmployersReferenceNumber { get; set; }

        [Display(Name = "Employers reference number two")]
        [RequiredIfTrue("ExemptFromHMCEEmployersReferenceNumber")]
        [MaxLength(25)]
        public string EmployersReferenceNumberTwo { get; set; }

        public override RepeatGroupBase RepeatGroupProperty
        {
            get { return this; }
        }
    }

    public enum CurrentPreviousInsurer
    {
        Axa,
        Towergate,
        Zurich
    }

    public enum CompanyStatus
    {
        Live,
        Inactive,
        AnotherStatus
    }

    public enum Trade
    {
        Builder,
        Plumber
    }

    public class PropertyOwnersDataCaptureTab : DataCaptureBase
    {
        public PropertyOwnersDataCaptureTab()
            : base(typeof(PropertyOwnersDataCapture))
        {
        }
    }

    public class PropertyOwnersDataCaptureTabOne : PropertyOwnersDataCaptureTab
    {
        public PropertyOwnersDataCaptureTabOne()
        {
            SubsidaryCompanies = new SubsidaryCompanyRepeatGroup();
        }

        [Display(Name = "Cover start date")]
        [Required]
        public DateTime CoverStartDate { get; set; }

        ////limit to two decimal places
        //[RegularExpression(@"^\d+.\d{0,2}$", ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "TargetPremiumDecimalPlaces")]
        [Display(Name = "Target premium")]
        [Range(0.00, 999999999.99, ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "TargetPremiumRange")]
        public decimal TargetPremium { get; set; }

        [Display(Name = "Current / previous insurer")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "CurrentPreviousInsurerRequired")]
        public CurrentPreviousInsurer? CurrentPreviousInsurer { get; set; }

        ////[CustomRequiredIf]
        [Display(Name = "Insurer information???")]
        public string InsurerInformation { get; set; }

        [Display(Name = "Company status")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "CompanyStatusRequired")]
        public CompanyStatus? CompanyStatus { get; set; }

        [Display(Name = "Trading name")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "TradingNameRequired")]
        [MaxLength(630)]
        public string TradingName { get; set; }

        [Display(Name = "All employees below the PAYE threshold")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "AllEmployeesPaidBelowPAYEThresholdRequired")]
        public bool? AllEmployeesPaidBelowPAYEThreshold { get; set; }

        [Display(Name = "Employers reference number")]
        [RequiredIfFalse("AllEmployeesPaidBelowPAYEThreshold")]
        [MaxLength(25)]
        public string EmployersReferenceNumber { get; set; }

        [Display(Name = "Individual name")]
        [UIHint("PersonalInformation")]
        public IList<PersonalInformation> PersonalInformation { get; set; }

        [Display(Name = "Address information")]
        public AddressInformation AddressInformation { get; set; }

        [Display(Name = "Trade")]
        [Required(ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "TradeRequired")]
        public Trade? Trade { get; set; }

        [Display(Name = "Trading name two")]
        [HelpText("TRADING NAME")]
        [Pretext("$")]
        [PostText("%")]
        [MaxLength(630)]
        public string TradingNameTwo { get; set; }

        [Display(Name = "Year established")]
        [Range(1000, 9999, ErrorMessageResourceType = typeof(iMarketResources), ErrorMessageResourceName = "YearEstablishedRange")]
        public short YearEstablished { get; set; }

        [Display(Name = "Do subsidiary companies exist?")]
        public bool SubsidiaryCompaniesExist { get; set; }

        [UIHint("SubsidiaryCompaniesContainer")]
        public SubsidaryCompanyRepeatGroup SubsidaryCompanies { get; set; }

    }

    public class SubsidaryCompanyRepeatGroup : RepeatGroupContainer
    {
        [Display(Name = "Subsidiary companies")]
        [MaximumRepeatGroups(10)]
        [UIHint("SubsidiaryCompanies")]
        public IList<SubsidiaryCompany> SubsidiaryCompanies { get; set; }

        public RepeatGroupBase GetPropertyType(string propertyName)
        {
            return (RepeatGroupBase)Activator.CreateInstance(this.GetType().GetProperty(propertyName).PropertyType.GetGenericArguments().FirstOrDefault());
        }

        public string GetTemplateName(string forProperty)
        {
            string templateName = ((UIHintAttribute)this.GetType().GetProperty(forProperty).GetCustomAttributes(typeof(UIHintAttribute), false).FirstOrDefault()).UIHint;

            return templateName;
        }
    }

    public interface RepeatGroupContainer
    {
        //string propertyName { get; set; }
        RepeatGroupBase GetPropertyType(string propertyName);
        string GetTemplateName(string forProperty);
    }

    public abstract class RepeatGroupBase
    {
        public abstract RepeatGroupBase RepeatGroupProperty { get; }
    }


    public class PropertyOwnersDataCaptureTabTwo : PropertyOwnersDataCaptureTab
    {
        ////[Display(Name = "Hello again")]
        ////[Required]
        ////public string HiMike { get; set; }

        ////[Display(Name = "What is your name")]
        ////[Required(ErrorMessage = "Please supply your name")]
        ////public string WhatIsYourName { get; set; }

        ////public SomethingNew SomethingNew { get; set; }

        ////public string SomethingElseNew { get; set; }
    }

    public class PropertyOwnersDataCapture
    {
        public PropertyOwnersDataCapture()
        {
            TabOne = new PropertyOwnersDataCaptureTabOne();

            TabTwo = new PropertyOwnersDataCaptureTabTwo();
        }

        public PropertyOwnersDataCaptureTabOne TabOne { get; set; }

        public PropertyOwnersDataCaptureTabTwo TabTwo { get; set; }
    }
}