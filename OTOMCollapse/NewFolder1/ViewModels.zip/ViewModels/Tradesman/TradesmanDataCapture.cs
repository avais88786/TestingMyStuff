﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OpenGI.MVC.ViewModels.Tradesman
{
    public class TradesmanDataCaptureTab : DataCaptureBase
    {
        public TradesmanDataCaptureTab()
            : base(typeof(TradesmanDataCapture))
        {
        }
    }

    public class TradesmanDataCaptureTabOne : TradesmanDataCaptureTab
    {
        [Display(Name = "Tradesman name")]
        [Required]
        public string TradesmanName { get; set; }
    }

    public class TradesmanDataCaptureTabTwo : TradesmanDataCaptureTab
    {
        [Display(Name = "Something else")]
        [Required]
        public string SomethingElse { get; set; }
    }

    public class TradesmanDataCapture
    {
        public TradesmanDataCapture()
        {
            TabOne = new TradesmanDataCaptureTabOne();

            TabTwo = new TradesmanDataCaptureTabTwo();
        }

        public TradesmanDataCaptureTabOne TabOne { get; set; }

        public TradesmanDataCaptureTabTwo TabTwo { get; set; }
    }
}