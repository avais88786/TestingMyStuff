﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OpenGI.MVC.ViewModels
{
    public class DataCaptureBase : IDataCapture
    {
        private Type _parentType { get; set; }

        [HiddenInput(DisplayValue = false)]
        public string BusinessLine
        {
            get
            {
                return this.GetType().ToString();
            }
        }

        public DataCaptureBase(Type parentType)
        {
            _parentType = parentType;
        }

        public Type GetParentType()
        {
            return _parentType;
        }
    }
}