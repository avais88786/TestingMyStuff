﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenGI.MVC.ViewModels
{
    public enum NumberOfClaims
    {
        Zero,
        One,
        Two,
        Three
    }
}
